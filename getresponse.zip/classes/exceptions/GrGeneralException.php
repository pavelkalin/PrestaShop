<?php

class GrGeneralException extends \Exception
{

}