<?php

class GrConfigurationNotFoundException extends GrGeneralException
{

}