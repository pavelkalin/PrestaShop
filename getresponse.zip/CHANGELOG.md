# Changelog

## 16.2.10_forked
*(2018-04-27)*

#### Bug fixes
* change curl timeout from 8 seconds to 40 seconds

## 16.2.10
*(2018-04-24)*

#### Bug fixes
* re-added cache in webforms with isCacheEnabled flag
* adjusted admin forms to old PrestaShop versions
* added length limitation for product variant description

## 16.2.9
*(2018-03-20)*

#### Bug fixes
* resign from cache in webforms

## 16.2.8
*(2018-03-08)*

#### Bug fixes
* fix bug with ecommerce rules
* fix bug with new order hook