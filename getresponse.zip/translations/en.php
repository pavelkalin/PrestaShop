<?php

global $_MODULE;
$_MODULE                                                                                = array();
$_MODULE['<{getresponse}prestashop>getresponsesubtab_5c23262b29669dd8bdf5f97d6db3b954'] = 'Use your GetResponse API Key';
$_MODULE['<{getresponse}prestashop>getresponse_f0180d584c18095d3476faa8b844434a']       = 'GetResponse';
$_MODULE['<{getresponse}prestashop>getresponse_71e0e74855165f4293e05c8ef8071c02']       = 'Add your Prestashop contacts to GetResponse or manage them via automation rules. Automatically follow-up new subscriptions with engaging email marketing campaigns';
$_MODULE['<{getresponse}prestashop>getresponse_95ef04a5d9b3d3161c9db67fc1e4e994']       = 'Are you sure?';
